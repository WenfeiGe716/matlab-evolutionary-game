function dxdt=differential(t,x)
dxdt=[x(1)*(1-x(1))*(0.9875*x(2)-0.3875);x(2)*(1-x(2))*(0.135*x(1)-0.075)];
end