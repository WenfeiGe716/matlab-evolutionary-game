%%����ļ��㣺F(X)=F(Y)=0������
n=0.1,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.1,sB=0.25;
syms x y;
[x,y]=solve(x*(1-x)*((1-n)*(1+rA)-(1-y)*(d-beta*fB*miu)+alpha*(sA+fA)-1)==0,y*(1-y)*(x*(1-theta)*(1+rA)*lamda-miu+beta*(sB+fB)*miu)==0);
x=vpa(x,3);y=vpa(y,3);
x
y
%%
clc;clear;close all;
n=0.1,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.1,sB=0.25;
figure()
subplot(1,4,1)
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.60 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'X=0.60,Y=0.40');
subplot(1,4,2)
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.50 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'X=0.50,Y=0.40');
subplot(1,4,3)
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.45]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'X=0.56,Y=0.45');
subplot(1,4,4)
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.35]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'X=0.56,Y=0.35');
title('ͼ4 ����ʵ����������1','FontWeight','bold','position',[-200 -0.12]);
%%
n=0.05,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.05,lamda=0.1,sB=0.25;
figure()
subplot(1,8,[1,2])
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'\eta=0.05,\theta=0.05');
subplot(1,8,[3,4])
n=0.1,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.15,alpha=0.5,sA=0.25,fA=0.25,theta=0.15,lamda=0.1,sB=0.25;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'\mu=0.15,\theta=0.15');
subplot(1,8,[5,6])
n=0.1,rA=0.5,d=1,beta=0.6,fB=0.3,miu=0.1,alpha=0.6,sA=0.3,fA=0.3,theta=0.1,lamda=0.1,sB=0.3;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'\alpha  = \beta  = 0.6','Fontsize',10);
text(42,0.30,'S_{A}=F_{A}=0.3');
text(42,0.20,'S_{B}=F_{B}=0.3');
subplot(1,8,[7,8])
n=0.1,rA=0.5,d=1,beta=0.4,fB=0.2,miu=0.1,alpha=0.4,sA=0.2,fA=0.2,theta=0.1,lamda=0.1,sB=0.2;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'\alpha  = \beta  = 0.4','Fontsize',10);
text(42,0.30,'S_{A}=F_{A}=0.2');
text(42,0.20,'S_{B}=F_{B}=0.2');
title('ͼ5 ����ʵ����������2','FontWeight','bold','position',[-200 -0.12]);
%%
n=0.1,rA=0.5,d=0.75,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.1,sB=0.25;
figure()
subplot(1,16,[1:4])
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'i=0.05,d=0.75');
subplot(1,16,[5:8])
n=0.1,rA=0.5,d=1.25,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.1,sB=0.25;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.40,'i=1.5,d=1.25');
subplot(1,16,[9:12])
n=0.1,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.1,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.15,sB=0.25;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.30,'\lambda=0.15,\mu=0.10');
subplot(1,16,[13,16])
n=0.1,rA=0.5,d=1,beta=0.5,fB=0.25,miu=0.15,alpha=0.5,sA=0.25,fA=0.25,theta=0.1,lamda=0.1,sB=0.25;
[t,y]=ode45(@(t,y) nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB),[0 100],[0.56 0.40]);
plot(t,y(:,1),'rs','lineWidth',1,'markerfacecolor','r');
hold on
plot(t,y(:,2),'bo','lineWidth',1,'markerfacecolor','b');
hold on  
set(gca,'XTick',[0:100:100],'YTick',[0:1:1])
set(0,'defaultfigurecolor','w')
axis([0 100 0 1])
le=legend('x','y')
set(le,'box','off')
xlabel('time','position',[50 -0.01]);
ylabel('proportion');
text(42,1.04,'the proportion');
text(42,0.30,'\lambda=0.10,\mu=0.15');
title('ͼ6 ����ʵ����������3','FontWeight','bold','position',[-200 -0.12]);