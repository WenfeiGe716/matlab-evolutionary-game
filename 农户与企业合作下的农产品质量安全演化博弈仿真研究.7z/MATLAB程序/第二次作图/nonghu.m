function dydt=nonghu(t,y,n,rA,d,beta,fB,miu,alpha,sA,fA,theta,lamda,sB)
dydt=zeros(2,1);
dydt(1)=y(1)*(1-y(1))*((1-n)*(1+rA)-(1-y(2))*(d-beta*fB*miu)+alpha*(sA+fA)-1);
dydt(2)=y(2)*(1-y(2))*(y(1)*(1-theta)*(1+rA)*lamda-miu+beta*(sB+fB)*miu);
end